# Unturned Server

Unturned 2.2.5 server rework.
 ***Linux binary included***
 (rebuilt with Unity Pro)

Functions:
* Integrated ModLoader
* Improoved Cheat protection with following cheats:
  * Inventory clear hack
  * Kick player with speedhack issue
  * Car teleport hack
  * Spam structures hack
  * Destroy structures hack
* Database support (now only MySQL, File databases)
* Reloadable BAN table (external changeable)
* Removed Steam, this will allows you to run multiple instances
* Fixed CPU overhead
* And so many feature...

ScreenShot from running instance (with ~8 players)
![linux_instance](https://cloud.githubusercontent.com/assets/2112862/5691029/f8f271d0-98b2-11e4-92b8-9212302d74fb.jpg)


